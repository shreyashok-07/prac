
# Import Libraries
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix

# ------------------------------------------
# Load Dataset
# ------------------------------------------

df = pd.read_csv(r"C:\Users\Shreyash Musmade\Desktop\Acadmics\BE_AIML\8th Sem\BDA\6\tripdata.csv")

# ------------------------------------------
# Display First 5 Rows
# ------------------------------------------

print("===================================")
print("FIRST 5 ROWS")
print("===================================")

print(df.head())

# ------------------------------------------
# Display Column Names
# ------------------------------------------

print("\n===================================")
print("COLUMN NAMES")
print("===================================")

print(df.columns)

# ==========================================
# Remove Missing Values
# ==========================================

df = df.dropna()

# ==========================================
# Convert Date Columns
# ==========================================

df['started_at'] = pd.to_datetime(df['started_at'])

df['ended_at'] = pd.to_datetime(df['ended_at'])

# ==========================================
# Create Trip Duration Feature
# ==========================================

df['trip_duration'] = (
    (df['ended_at'] - df['started_at']).dt.total_seconds() / 60
)

# ==========================================
# Encode Rideable Type
# ==========================================

ride_encoder = LabelEncoder()

df['rideable_type_encoded'] = ride_encoder.fit_transform(
    df['rideable_type']
)

# ==========================================
# Features
# ==========================================

X = df[['trip_duration', 'rideable_type_encoded']]

# ==========================================
# Target Variable
# ==========================================

y = df['member_casual']

# Encode Target
target_encoder = LabelEncoder()

y = target_encoder.fit_transform(y)

# ==========================================
# Split Dataset
# ==========================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# ==========================================
# Train Model
# ==========================================

model = RandomForestClassifier()

model.fit(X_train, y_train)

# ==========================================
# Make Predictions
# ==========================================

y_pred = model.predict(X_test)

# ==========================================
# Evaluate Model
# ==========================================

print("\n===================================")
print("MODEL ACCURACY")
print("===================================")

accuracy = accuracy_score(y_test, y_pred)

print("Accuracy:", accuracy)

# Confusion Matrix
print("\nConfusion Matrix:")

print(confusion_matrix(y_test, y_pred))

# Classification Report
print("\nClassification Report:")

print(classification_report(y_test, y_pred))

# ==========================================
# Sample Prediction
# ==========================================

# Example:
# trip_duration = 20 minutes
# rideable_type_encoded = 1

sample = [[20, 1]]

prediction = model.predict(sample)

print("\n===================================")
print("SAMPLE PREDICTION")
print("===================================")

if prediction[0] == 1:
    print("Member User")
else:
    print("Casual User")