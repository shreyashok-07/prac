# ==========================================
# WEATHER DATABASE ANALYSIS
# FIND DAY AND STATION WITH
# MAXIMUM PRECIPITATION IN 2013
# ==========================================

# Import Required Library
import pandas as pd

# ------------------------------------------
# Load Dataset
# ------------------------------------------

# Replace with your dataset filename
df = pd.read_csv("4\weather.csv")

# ------------------------------------------
# Display First 5 Rows
# ------------------------------------------

print("===================================")
print("FIRST 5 ROWS")
print("===================================")

print(df.head())

# ------------------------------------------
# Display Column Names
# ------------------------------------------

print("\n===================================")
print("COLUMNS IN DATASET")
print("===================================")

print(df.columns)

# ==========================================
# Convert DATE Column into Datetime
# ==========================================

df['DATE'] = pd.to_datetime(df['DATE'])

# ==========================================
# Filter Records for Year 2013
# ==========================================

data_2013 = df[df['DATE'].dt.year == 2013]

print("\n===================================")
print("TOTAL RECORDS IN 2013")
print("===================================")

print(len(data_2013))

# ==========================================
# Check Missing Values in PRCP
# ==========================================

print("\n===================================")
print("MISSING VALUES IN PRCP COLUMN")
print("===================================")

print(data_2013['PRCP'].isnull().sum())

# ==========================================
# Remove Missing Values
# ==========================================

data_2013 = data_2013.dropna(subset=['PRCP'])

# ==========================================
# Find Maximum Precipitation
# ==========================================

max_prcp = data_2013['PRCP'].max()

print("\n===================================")
print("MAXIMUM PRECIPITATION")
print("===================================")

print(max_prcp)

# ==========================================
# Find Day and Station
# ==========================================

result = data_2013[data_2013['PRCP'] == max_prcp]

# ==========================================
# Display Final Result
# ==========================================

print("\n===================================")
print("DAY AND STATION WITH MAXIMUM")
print("PRECIPITATION IN 2013")
print("===================================")

print(result[['DATE', 'STATION', 'NAME', 'PRCP']])

# ==========================================
# Additional Details
# ==========================================

print("\n===================================")
print("ADDITIONAL DETAILS")
print("===================================")

print("\nDate:")
print(result['DATE'].values)

print("\nStation ID:")
print(result['STATION'].values)

print("\nStation Name:")
print(result['NAME'].values)

print("\nPrecipitation Value:")
print(result['PRCP'].values)